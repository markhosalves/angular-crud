(function (angular, undefined) {
    'use strict';
    angular.module('cadpat', [
        'ngResource',
        'ngRoute',
        'cadpatFilters',
        'cadpatServices',
        'bemControllers',
        'angular-input-stars',
        'ui.bootstrap'
    ]);
})(angular);
