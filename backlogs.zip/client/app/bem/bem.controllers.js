(function(angular, undefined) {
    'use strict';

    angular
    .module('bemControllers', [])
    .controller('ListagemController', ListagemController)
    .controller('DetalheController', DetalheController)
    .controller('IncluirController', IncluirController)
    .controller('AlterarController', AlterarController);

    AlterarController.$inject = ['$location', '$routeParams', '$window', 'bemService'];

    function AlterarController($location, $routeParams, $window, bemService) {
        var vm = this;
        vm.salvar = salvar;

        activate();

        ////////////////

        function activate() {
            bemService.get({
                id: $routeParams.id,
            }, function(bem) {
                vm.bem = bem;
            }, function(erro) {
                $window.alert(erro);
            });
        }

        function salvar() {
            bemService.update({
                id: $routeParams.id,
            },
            vm.bem,
            function() {
                $window.alert('Bem alterado com sucesso');
                $location.path('/projetos');
            },
            function(erro) {
                $window.alert(erro);
            });
        }
    }

    IncluirController.$inject = ['$location', '$window', 'bemService'];

    function IncluirController($location, $window, bemService) {
        var vm = this;
        vm.bem = {};
        vm.salvar = salvar;



        vm.potencial = 0;
        vm.max = 10;
        vm.isReadonly = false;

        vm.hoveringOver = function(value) {
          vm.overStar = value;
          vm.percent = 100 * (value / vm.max);
        };




        vm.language = 'pt-BR';

        vm.today = function() {
            vm.dt = new Date();
        };

        vm.today();

        vm.clear = function() {
            vm.dt = null;
        };

        vm.inlineOptions = {
            customClass: getDayClass,
            minDate: new Date(),
            showWeeks: false
        };

        vm.dateOptions = {
            //dateDisabled: disabled,
            formatYear: 'yy',
            maxDate: new Date(2020, 5, 22),
            minDate: new Date(),
            startingDay: 0,
            showWeeks: false
        };

        vm.toggleMin = function() {
            vm.inlineOptions.minDate = vm.inlineOptions.minDate ? null : new Date();
            vm.dateOptions.minDate = vm.inlineOptions.minDate;
        };

        vm.toggleMin();

        vm.open1 = function() {
            vm.popup1.opened = true;
        };


        vm.setDate = function(year, month, day) {
            vm.dt = new Date(year, month, day);
        };

        vm.formats = ['dd/MM/yyyy', 'shortDate'];
        vm.format = vm.formats[0];
        vm.altInputFormats = ['M!/d!/yyyy'];

        vm.popup1 = {
            opened: false
        };

        function getDayClass(data) {
            var date = data.date,
                mode = data.mode;
            if (mode === 'day') {
                var dayToCheck = new Date(date).setHours(0, 0, 0, 0);

                for (var i = 0; i < vm.events.length; i++) {
                    var currentDay = new Date(vm.events[i].date).setHours(0, 0, 0, 0);

                    if (dayToCheck === currentDay) {
                        return vm.events[i].status;
                    }
                }
            }

            return '';
        }






        ////////////////

        function salvar() {
            if (vm.frmbem.$valid) {
                bemService.save(
                    vm.bem,
                    function() {
                        $window.alert('Bem incluído com sucesso');
                        $location.path('/projetos');
                    },
                    function(erro) {
                        $window.alert(erro);
                    });
            }
        }
    }

    DetalheController.$inject = ['$routeParams', '$window', 'bemService'];

    function DetalheController($routeParams, $window, bemService) {
        var vm = this;

        activate();

        ////////////////

        function activate() {
            bemService.get({
                id: $routeParams.id,
            }, function(bem) {
                vm.bem = bem;
            }, function(erro) {
                $window.alert(erro);
            });
        }
    }

    ListagemController.$inject = ['$window', 'bemService'];

    function ListagemController($window, bemService) {
        var vm = this;

        vm.excluir = excluir;
        
        activate();


        ////////////////

        function activate() {
            bemService.query(function(bens) {
                vm.bens = bens;
                vm.property = 4;
                vm.rfinanceiro = 3
            },
            function(erro) {
                $window.alert(erro);
            });
        }

        function excluir(id) {
            if (!$window.confirm('Confirma a exclusão do bem id: ' + id + '?')) {
                return;
            }

            bemService.delete({
                id: id,
            }, function() {
                $window.alert('Bem excluído com sucesso!');
                activate();
            }, function(erro) {
                $window.alert(erro);
            });
        }
    }

})(angular);
