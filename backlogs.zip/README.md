# cadastro-patrimonio-ng
Aplicação Exemplo de Cadastro de Patrimônio em AngularJS

# Instalação do NodeJS

> sudo apt-get purge nodejs npm

> sudo apt-get install -y build-essential

> curl 
  -sL https://deb.nodesource.com/setup_4.x
  | sudo -E bash –

> sudo apt-get install -y nodejs

> node --version
< v4.4.5

> npm --version
< 2.15.5


> sudo add-apt-repository ppa:git-core/ppa
> sudo apt-get update
> sudo apt-get install git
> git --version
< git version 2.9.0

Bacen
http://bit.ly/imgbacen

Palácio do Buriti
http://bit.ly/imgburiti
https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/CITY_HALL%2C_BRASILIA.jpg/220px-CITY_HALL%2C_BRASILIA.jpg

Câmara Legislativa DF
http://bit.ly/imgcamara
https://upload.wikimedia.org/wikipedia/commons/thumb/d/d2/Camara_Legislativa_do_DF_2012.jpg/220px-Camara_Legislativa_do_DF_2012.jpg

Congresso Nacional
http://bit.ly/imgcongresso
https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Congresso_do_Brasil.jpg/220px-Congresso_do_Brasil.jpg